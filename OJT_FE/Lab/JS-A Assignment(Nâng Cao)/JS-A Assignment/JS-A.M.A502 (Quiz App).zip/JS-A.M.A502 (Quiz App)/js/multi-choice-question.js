class MultiChoiceQuestion extends Question {
  constructor(q) {
    super(q);
  }

  // Problem 2: Implement code here
  render() {
  }
}
